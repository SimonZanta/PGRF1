package rasterData;

import java.awt.*;

public interface Presentable {

    void present(Graphics graphics);

}
